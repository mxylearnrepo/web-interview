# AJAX
```js
const getJSON = function(url) {
  return new Promise((resolve, reject) => {
    const xhr = XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Mscrosoft.XMLHttp')
    xhr.open('GET', url, false)
    xhr.setRequestHeader('Accept', 'application/json')
    xhr.onreadystatechange = function() {
      if (xhr.readyState !== 4) return
      if (xhr.status === 200 || xhr.status === 304) {
          resolve(xhr.responseText)
      } else {
          reject(new Error(xhr.responseText))
      }
    }
    xhr.send()
  })
}
```

# JSONP
script 标签不受同源策略约束, 所以可以执行跨域请求
优点是兼容性好, 缺点是只支持 GET 请求
```js
const jsonp = ({ url, params, callbackName }) => {
  const generateUrl = () => {
    let dataSrc = ''
    for (let key in params) {
      if (params.hasOwnProperty(key)) {
        dataSrc += `${key}=${params[key]}&`
      }
    }
    dataSrc += `callback=${callbackName}`
    return `${url}?${dataSrc}`
  }
  return new Promise((resolve, reject) => {
    const scriptEle = document.createElement('script')
    scriptEle.src = generateUrl()
    document.body.appendChild(scriptEle)
    window[callbackName] = data => {
      resolve(data)
      document.removeChild(scriptEle)
    }
  })
}
```
JSONP 需要服务端的配合, 这样的请求发出去后, 服务端应当返回这样的 result:
```js
"callbackName({\"userId\":1,\"username\":\"maos\"})"
```
script 标签在拿到这个东西后会调用全局 (window 上的) callbackName 函数
并把括号里的 JSON 数据作为这个函数的第一个参数 (需要 JSON.parse 一下)
