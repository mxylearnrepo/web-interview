思考:
  await new Promise(async (resolve, reject) => { ... })
  会发生什么?